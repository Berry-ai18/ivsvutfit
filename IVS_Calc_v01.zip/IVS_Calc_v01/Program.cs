﻿/**********************************************************************************************
 * Názov projektu: Kalkulačka IVS
 * Súbor: Program.cs
 * Dátum: 18.04.2020
 * Posledná zmena: 18.04.2020
 * Autor: Andrej Hýroš - xhyros00
 * Popis: Súbor obsahujúci main funkciu aplikácie
 * ********************************************************************************************/
/**
 * @file Program.cs
 * @brief Súbor obsahujúci main funkciu aplikácie
 * @author Andrej Hýroš
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IVS_Calc_v01
{
    /**
     * @class Trieda obsahujúca main funkciu aplikácie
     */
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        /**
         * Main funkcia aplikácie
         */
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
