﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;
//using calclibrary;
using ClassLibrary_IVS;


namespace IVS_Calc_v01
{
    public partial class Form1 : Form
    {
        //desatinny operator = true
        bool isDecimal = false;

        bool mathError = false;

        //zadana operacia = true
        bool opPerformed = false;

        //stlacene =
        bool eqClicked = false;
        double result = 0;

        //prazdny string na ulozenie operatora
        string op = "";
        string mE = "Math Error";

        bool parsed = false;

        public Form1()
        {
            InitializeComponent();
        }

        //funkcia vypise "Math Error" na obrazovku a nastavi mathError
        private void mathErr()
        {
            textBox.Text = mE;
            mathError = true;
        }

        //funkcia vypise "Syntax Error" na obrazovku a nastavy mathError
        private void syntErr()
        {
            textBox.Text = "Syntax Error";
            mathError = true;
        }

        //ciselne tlacidla a desatinna ciarka budu stlacitelne
        private void valuesEnabled()
        {
            numberZero.Enabled = true;
            numberOne.Enabled = true;
            numberTwo.Enabled = true;
            numberThree.Enabled = true;
            numberFour.Enabled = true;
            numberFive.Enabled = true;
            numberSix.Enabled = true;
            numberSeven.Enabled = true;
            numberEight.Enabled = true;
            numberNine.Enabled = true;
            coma.Enabled = true;
        }

        //ciselne tlacidla a desatinna ciarka nebudu stlacitelne
        private void valuesDisabled()
        {
            numberZero.Enabled = false;
            numberOne.Enabled = false;
            numberTwo.Enabled = false;
            numberThree.Enabled = false;
            numberFour.Enabled = false;
            numberFive.Enabled = false;
            numberSix.Enabled = false;
            numberSeven.Enabled = false;
            numberEight.Enabled = false;
            numberNine.Enabled = false;
            coma.Enabled = false;
        }

        //operatory budu stlacitelne
        private void operationsEnabled()
        {
            add.Enabled = true;
            sub.Enabled = true;
            mul.Enabled = true;
            div.Enabled = true;
            powerOf.Enabled = true;
            sqrt.Enabled = true;
            factorial.Enabled = true;
            abs.Enabled = true;
        }

        //operatory nebudu stlacitelne
        private void operationsDisabled()
        {
            add.Enabled = false;
            sub.Enabled = false;
            mul.Enabled = false;
            div.Enabled = false;
            powerOf.Enabled = false;
            sqrt.Enabled = false;
            factorial.Enabled = false;
            abs.Enabled = false;
        }

        //AC stlacene
        private void clear_Click(object sender, EventArgs e)
        {
            textBox.Text = "0";
            result = 0;
            mathError = false;
            isDecimal = false;

            valuesEnabled();
            operationsEnabled();
            equal.Enabled = true;
        }

        



        //? stlaceny
        private void help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Help Guide\n" +
                "Kalkulacka zvlada nasledujuce operacie: scitanie(+), odcitanie(-), nasobenie(×), delenie(÷), prirodzene exponenty((x)ʸ), obecnu odmocninu(√), faktorial(!) a absolutnu hodnotu(|x|)\n\n" +
                "Postup: Uzivatel zada ciselny operand, nasledne zvoli operator a v priprade binarnej operacie zada druhy operand, pricom po stlaceni klavesy \"=\" sa vypise vysledok a je mozne pokracovat " +
                "v zadani dalsieho operatoru.\n" +
                "V pripade unarnej operacie sa vypise vysledok ihned po zadani operatora a je mozne zadat dalsi operator.\n" +
                "Po zadani operatora musi nasledovat ciselny operand.\n\n" +
                "V pripade vysledku \"Math Error\", \"Syntax Error\" alebo \"Error: Out of Range\" musi uzivatel stlacit klavesu \"AC\" a moze pokracovat v pocitani");
        }








        //stlacene cislo alebo desatinna ciarka
        private void numClick(object sender, EventArgs e)
        {
            if ((textBox.Text == "0") || (opPerformed == true)) {
                textBox.Clear();
            }


            opPerformed = false;
            Button numButton = (Button)sender;

            if (textBox.Text == ".")
            {
                textBox.Text = "0.";
            }

            if (numButton.Text == ".") {
                isDecimal = true;
                if (!textBox.Text.Contains(".")) {
                    textBox.Text = textBox.Text + numButton.Text;
                }
            }
            else

            //pripisovanie cisel pre viacciferne honoty
            textBox.Text = textBox.Text + numButton.Text;
         

        }








        //stlaceny operator
        private void opClick(object sender, EventArgs e)
        {
            equal.Enabled = true;
            operationsDisabled();
            valuesEnabled();

            Button opButton = (Button)sender;

            if ((result != 0) && (eqClicked == false)) {
                equal.PerformClick();

                equal.Enabled = true;

                valuesEnabled();

                op = opButton.Text;
                opPerformed = true;
                //equal.PerformClick();

            }
            else
            {
                op = opButton.Text;
                result = Double.Parse(textBox.Text);
                opPerformed = true;
                eqClicked = false;
            }

            //v pripade tychto troch operacii sa stlaci = automaticky
            if (opButton.Text == "!" || opButton.Text == "|x|")
            {
                equal.PerformClick();
            }
        }






        //vytovorenie instancie triedy s funkciami
        calculate kalk = new calculate();

        //= stlacene
        private void eqClick(object sender, EventArgs e)
        {
            //switch rozlisi ktora operacia ma nasledovat
            switch (op)
            {
                case "+":
                    textBox.Text = (kalk.plus(result, Double.Parse(textBox.Text))).ToString();
                    break;

                case "-":
                    textBox.Text = (kalk.sub(result, Double.Parse(textBox.Text))).ToString();
                    break;

                case "×":
                    textBox.Text = (kalk.mul(result, Double.Parse(textBox.Text))).ToString();
                    break;

                case "÷":
                    if (textBox.Text == "0")
                    {
                        mathErr();
                        break;
                    }
                    textBox.Text = (kalk.div(result, Double.Parse(textBox.Text))).ToString();
                    break;

                case "(x)ʸ":
                    int exponent;
                    parsed = Int32.TryParse(textBox.Text, out exponent);
                    if (parsed == true)
                    {
                        textBox.Text = (kalk.expo(result, exponent)).ToString();
                        if (textBox.Text == "∞")
                        {
                            textBox.Text = "Error: Out of Range...";
                            mathError = true;
                        }
                    }
                    else
                    {
                        syntErr();
                        break;
                    }
                    parsed = false;
                    break;
                    //koniec case: (x)ʸ



                case "√":
                    if (result == 0)
                    {
                        textBox.Text = "0";
                        break;
                    }
                    if (result < 0)
                    {
                        mathErr();
                        break;
                    }
                    int index;
                    parsed = Int32.TryParse(textBox.Text, out index);
                    if (index == 0)
                    {
                        mathErr();
                        break;
                    }


                    if (parsed == true)
                    {
                        textBox.Text = (kalk.ntrt(result, index)).ToString("0.00000000");
                        if (textBox.Text == "∞")
                        {
                            textBox.Text = "Error: Out of Range...";
                            mathError = true;
                        }
                    }
                    else
                    {
                        syntErr();
                        break;
                    }
                    parsed = false;
                    break;
                    //koniec case: √


                case "!":
                    if (result == 0)
                    {
                        textBox.Text = "1";
                        break;
                    }
                    if (result < 0 || isDecimal == true)
                    {
                        mathErr();
                        break;
                    }
                    textBox.Text = (kalk.fact(result)).ToString();
                    break;


                case "|x|":
                    textBox.Text = (kalk.abs(result)).ToString();
                    break;

                default:
                    break;
            }
            //koniec switchu



            equal.Enabled = false;
            valuesDisabled();

            //ak plati matherror deaktivuju sa tlacitka, ak neplati, pokracuje sa dalej
            if (mathError == false)
            {
                operationsEnabled();
                eqClicked = true;
                result = Double.Parse(textBox.Text);
            }
            else
            {
                valuesDisabled();
                operationsDisabled(); 
                equal.Enabled = false;
                
            }
        }
    }
}
